Mutation Testing Artifacts

mutatest_run.txt
    Full mutation testing execution output.

interesting_mutants.txt
    Extracted list of generated mutants.

selected_mutants.csv
    Structured overview of selected mutants used in the report.

before/
    Original versions of validation logic and tests prior to mutation-driven improvements.

after/
    Updated versions after strengthening tests and fixing validation behaviour.